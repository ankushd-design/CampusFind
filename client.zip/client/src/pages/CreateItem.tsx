import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

import api from "../services/api";
import Input from "../components/Input";
import Button from "../components/Button";

function CreateItem() {
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Electronics");
  const [type, setType] = useState("Lost");
  const [location, setLocation] = useState("");

  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState("");

  const [loading, setLoading] = useState(false);

  const handleImageChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];

    if (!file) return;

    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (
      !title.trim() ||
      !description.trim() ||
      !location.trim()
    ) {
      toast.error("Please fill all required fields.");
      return;
    }

    setLoading(true);

    try {
      const token = localStorage.getItem("token");

      const formData = new FormData();

      formData.append("title", title);
      formData.append("description", description);
      formData.append("category", category);
      formData.append("type", type);
      formData.append("location", location);

      if (image) {
        formData.append("image", image);
      }

      await api.post("/items", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      toast.success("Item created successfully!");

      navigate("/");
    } catch (err: any) {
      toast.error(
        err.response?.data?.message ||
          "Failed to create item."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-10">
      <div className="mx-auto max-w-2xl rounded-xl bg-white p-8 shadow-lg">
        <h1 className="mb-2 text-center text-4xl font-bold">
          Create Item
        </h1>

        <p className="mb-8 text-center text-gray-500">
          Report a lost or found item to help others.
        </p>

        <form onSubmit={handleSubmit}>
          <Input
            name="title"
            label="Item Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Black Wallet"
          />

          <div className="mb-5">
            <label className="mb-2 block font-medium text-gray-700">
              Description
            </label>

            <textarea
              rows={4}
              value={description}
              onChange={(e) =>
                setDescription(e.target.value)
              }
              placeholder="Describe the item..."
              className="w-full rounded-lg border border-gray-300 p-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
            />
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            <div>
              <label className="mb-2 block font-medium text-gray-700">
                Category
              </label>

              <select
                value={category}
                onChange={(e) =>
                  setCategory(e.target.value)
                }
                className="w-full rounded-lg border border-gray-300 p-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              >
                <option>Electronics</option>
                <option>Documents</option>
                <option>Clothing</option>
                <option>Accessories</option>
                <option>Books</option>
                <option>Others</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block font-medium text-gray-700">
                Type
              </label>

              <select
                value={type}
                onChange={(e) =>
                  setType(e.target.value)
                }
                className="w-full rounded-lg border border-gray-300 p-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              >
                <option>Lost</option>
                <option>Found</option>
              </select>
            </div>
          </div>

          <div className="mt-5">
            <Input
              name="location"
              label="Location"
              value={location}
              onChange={(e) =>
                setLocation(e.target.value)
              }
              placeholder="Library, Block A..."
            />
          </div>

          <div className="mb-5">
            <label className="mb-2 block font-medium text-gray-700">
              Upload Image (Optional)
            </label>

            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="w-full rounded-lg border border-gray-300 p-3"
            />
          </div>

          {preview && (
            <div className="mb-6">
              <img
                src={preview}
                alt="Preview"
                className="h-72 w-full rounded-xl border object-cover"
              />
            </div>
          )}

          <Button
            type="submit"
            loading={loading}
          >
            Create Item
          </Button>
        </form>
      </div>
    </div>
  );
}

export default CreateItem;